-----------------------USER GUIDE TO USE THE LIBRARY MANAGEMENT SYSTEM-----------------------------------------------------------------

-----1)Install Mamp and start your Mamp server
-----2)Change the port of MySQL to 3307 from Preferences.
-----2)Import the data.sql file for the database in phpmyadmin.	
-----3)Unzip the file pnp170130_cs6360.zip in the htdocs folder of mamp and type this in your url "localhost/pnp170130_cs6360/library.html".
-----4)Use the UI which is displayed when you go to the link "localhost/pnp170130_cs63630/library.html" to navigate through various modules like searching the books,add borrowers,return book and check fine/pay fines.